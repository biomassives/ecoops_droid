package com.example.drawer444.ui.checkins

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CheckinsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Checkins provide a record of your activities and can used to generate reports designed to help projects gain credibility and recognition from international climate and biodiversity credits and incentives.  "
    }
    val text: LiveData<String> = _text
}
