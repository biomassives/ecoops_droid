package com.example.drawer444.ui.sales

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SalesViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {

        value = "Sales shown include those made within your circular economic spheres of influence. Sales are not shared unless set as public in settings."

    }
    val text: LiveData<String> = _text
}