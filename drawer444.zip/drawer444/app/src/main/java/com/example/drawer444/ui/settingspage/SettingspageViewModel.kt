package com.example.drawer444.ui.settingspage
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SettingspageViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Eco Ops Settings allow you to manage how your data is shared, how your group features work, and what kind of projects you get/ are getting promotion and support on."
    }
    val text: LiveData<String> = _text
}