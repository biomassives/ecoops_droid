package com.example.drawer444.ui.rewards

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class RewardsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Eco Ops participants and app users are rewarded 3d model NFTs on randomly selected exo planet design model public blockchain spheres to help test circular economy models in the exoworld.cc metaverse.   * virtual real estate by being granted ownership by nft wallet owner transfer ( gas is paid by credit, user or sponsor) "
    }
    val text: LiveData<String> = _text
}