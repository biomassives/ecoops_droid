package com.example.drawer444.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value =
            "Welcome to Eco Ops App, a free app, open source tool designed to help you to provide a verified record of ecologically beneficial activities.  You can discuss and learn more about what actions are considered beneficial and why. You can also earn certification to validate activities of others."
    }
    val text: LiveData<String> = _text
}