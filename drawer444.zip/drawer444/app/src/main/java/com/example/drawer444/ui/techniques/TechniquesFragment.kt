package com.example.drawer444.ui.techniques

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.drawer444.databinding.FragmentTechniquesBinding

class TechniquesFragment : Fragment() {

    private var _binding: FragmentTechniquesBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val techniquesViewModel =
            ViewModelProvider(this).get(TechniquesViewModel::class.java)

        _binding = FragmentTechniquesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textTechniques
        techniquesViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}