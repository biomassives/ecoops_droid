package com.example.drawer444.ui.reports

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ReportsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Reports are generated from your activities and can be shared among group members. Eco Ops reports are designed to clearly document how your actions were performed, gie credit to volunteers, contributors, and collaborators, and show how the project will continue to develop in the future. /r /r /r **** /n /n /n  me help with virtual real estate by being granted ownership title of 3d model NFTs on randomly selected exo-planet based sustainable living models on the public blockchain to help test circular economy models in the exoworld.cc MetaVerse."
    }
    val text: LiveData<String> = _text
}