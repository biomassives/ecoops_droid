package com.example.drawer444.ui.techniques

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TechniquesViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "The ways that we improve our biodiversity and natural places, address toxic sites and waterways, ways that we plan successful waste to product pathways. "
    }
    val text: LiveData<String> = _text
}