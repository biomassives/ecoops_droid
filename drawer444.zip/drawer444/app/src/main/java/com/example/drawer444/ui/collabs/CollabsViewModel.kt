package com.example.drawer444.ui.collabs
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CollabsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Collaboration allows you to take different roles relative to projects lead by other users of eco ops app:"
    }
    val text: LiveData<String> = _text
}