package com.example.drawer444.ui.validate

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ValidateViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Good record-keeping on Eco Ops App invites international sponsorship via carbon credit or biodiversity credit sales.  Verification relies on transparency, trust and peer review, and the discussion of how to be a catalyst in our communities for the fostering circular economies. "
    }


    val text: LiveData<String> = _text

}